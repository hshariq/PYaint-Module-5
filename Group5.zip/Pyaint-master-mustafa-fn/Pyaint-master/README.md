# Pyaint
An open source paint program using Python and Pygame. Features will be added by the community as time goes on.

You can go to the Wiki to get more details on this project.

It is an effort to encourage students to do problem solving and learn to contribute to the Opensource community
