---
name: A toolbar on right hand side containing new buttons
about: We need a toolbar on right hand side to keep all the tools
title: ''
labels: enhancement
assignees: ''

---

**Problem.**
We need a toolbar for containing all the tools on the right hand side for quick access.

**Acceptable Solution**
The right hand side should have a toolbar for containing separate buttons. We should also have tab functionality to swap between different toolbars. The code needs to be dynamic.
