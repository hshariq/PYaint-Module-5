from .settings import *
from .button import *
import pygame
pygame.init()
pygame.font.init()