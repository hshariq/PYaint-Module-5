class StraightLine:
    def __init__(self, start, end):
        self.start = start
        self.end = end

    # def drawSL(self):
    #     # pygame.draw.line(WIN, (0, 0, 0), start, end)

